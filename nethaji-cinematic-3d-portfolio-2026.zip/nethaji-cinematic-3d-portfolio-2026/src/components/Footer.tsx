import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Globe, Shield, Terminal, Heart } from 'lucide-react';
import { playSound } from '../utils/audio';

export default function Footer() {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('en-US', {
          timeZone: 'Asia/Kolkata',
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' IST'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="relative z-10 border-t border-white/10 bg-[#070707] py-14 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF1744] via-[#FF6A00] to-[#D4AF37] p-[1px] shadow-neon-red">
            <div className="w-full h-full bg-[#0A0A0A] rounded-[11px] flex items-center justify-center">
              <span className="font-heading font-black text-[#FF1744] text-lg">N</span>
            </div>
          </div>
          <div>
            <div className="font-heading font-black text-white text-base tracking-wider">
              A. NETHAJI <span className="text-[#FF1744]">/ 2026</span>
            </div>
            <div className="text-xs font-mono text-muted-grey">
              SOFTWARE DEVELOPER // PORTFOLIO 2026
            </div>
          </div>
        </div>

        {/* Live System Diagnostics */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-muted-grey">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10">
            <span className="w-2 h-2 rounded-full bg-[#FF1744] animate-ping" />
            <span className="text-white">SYSTEM OPERATIONAL</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[#D4AF37]">
            <Globe className="w-3.5 h-3.5" />
            <span>{time}</span>
          </div>
        </div>

        {/* Copyright & Location */}
        <div className="text-center md:text-right text-xs font-mono text-muted-grey">
          <div>ENGINEERED FOR EXCELLENCE</div>
          <div className="text-white/60 mt-0.5">TAMIL NADU, INDIA // ALL RIGHTS RESERVED</div>
        </div>

      </div>
    </footer>
  );
}

