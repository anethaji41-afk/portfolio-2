import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, FileText, ExternalLink } from 'lucide-react';
import { playSound } from '../utils/audio';

export default function ResumeModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl bg-[#111111] border border-[#FF1744]/40 shadow-neon-red overflow-hidden"
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 border-b border-white/10 bg-black/75">
            <div className="flex items-center gap-2 text-white font-heading font-bold text-sm sm:text-base">
              <FileText className="w-5 h-5 text-[#FF1744]" />
              <span>A. NETHAJI — OFFICIAL RESUME</span>
            </div>

            <div className="flex items-center gap-2">
              <a
                href="/NETHAJI_A.pdf"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('click')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-white/10 hover:bg-white/20 text-soft-white border border-white/15 transition-colors"
                title="Open in new window"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>OPEN IN TAB</span>
              </a>

              <a
                href="/NETHAJI_A.pdf"
                download="A_Nethaji_Resume.pdf"
                onClick={() => playSound('click')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-mono bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] text-white font-bold flex items-center gap-1.5 hover:opacity-95 shadow-neon-red transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>DOWNLOAD PDF</span>
              </a>

              <button
                onClick={() => {
                  playSound('click');
                  onClose();
                }}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-muted-grey hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive PDF Document Viewer */}
          <div className="flex-1 w-full h-[76vh] bg-[#070707] p-2 sm:p-4">
            <object
              data="/NETHAJI_A.pdf#toolbar=1&navpanes=0"
              type="application/pdf"
              className="w-full h-full rounded-xl border border-white/10 shadow-2xl"
            >
              <iframe
                src="/NETHAJI_A.pdf"
                className="w-full h-full rounded-xl border border-white/10"
                title="A. Nethaji Official Resume"
              >
                <div className="flex flex-col items-center justify-center h-full text-center p-8 text-white space-y-4">
                  <FileText className="w-12 h-12 text-[#FF1744]" />
                  <p className="text-base font-heading">
                    Official Resume Document (PDF)
                  </p>
                  <p className="text-xs text-muted-grey max-w-sm font-mono">
                    Your browser does not support embedded PDF viewing directly. Please click below to download or view online.
                  </p>
                  <a
                    href="/NETHAJI_A.pdf"
                    download="A_Nethaji_Resume.pdf"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF1744] to-[#FF6A00] text-white font-mono text-xs font-bold shadow-neon-red"
                  >
                    DOWNLOAD A_NETHAJI_RESUME.PDF
                  </a>
                </div>
              </iframe>
            </object>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
