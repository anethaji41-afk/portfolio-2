import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Volume2, VolumeX, FileText, ChevronRight } from 'lucide-react';
import { playSound, setSoundEnabled } from '../utils/audio';

interface NavbarProps {
  onOpenResume: () => void;
}

export default function Navbar({ onOpenResume }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrolled, setScrolled] = useState(false);
  const [soundOn, setSoundOn] = useState(false);

  const navItems = [
    { label: 'HOME', href: '#home', id: 'home' },
    { label: 'ABOUT', href: '#about', id: 'about' },
    { label: 'EXPERIENCE', href: '#experience', id: 'experience' },
    { label: 'SKILLS', href: '#skills', id: 'skills' },
    { label: 'PROJECTS', href: '#projects', id: 'projects' },
    { label: 'JOURNEY', href: '#journey', id: 'journey' },
    { label: 'EDUCATION', href: '#education', id: 'education' },
    { label: 'CONTACT', href: '#contact', id: 'contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      const sections = ['contact', 'education', 'journey', 'projects', 'skills', 'experience', 'about', 'home'];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(section);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleSound = () => {
    const nextState = !soundOn;
    setSoundOn(nextState);
    setSoundEnabled(nextState);
    if (nextState) {
      playSound('toggle');
    }
  };

  const handleNavClick = (id: string) => {
    playSound('click');
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 py-3 sm:py-4 px-4 sm:px-6 lg:px-8 ${
          scrolled ? 'bg-[#050505]/90 backdrop-blur-xl border-b border-white/10 shadow-lg' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo / Brand Name */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('home');
            }}
            className="flex items-center gap-2 group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF1744] via-[#FF6A00] to-[#D4AF37] p-[1px] shadow-neon-red group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#0A0A0A] rounded-[11px] flex items-center justify-center">
                <span className="font-heading font-black text-[#FF1744] text-lg">N</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-black text-sm sm:text-base tracking-wider text-soft-white group-hover:text-[#FF1744] transition-colors">
                A. NETHAJI
              </span>
              <span className="text-[10px] font-mono text-[#D4AF37] tracking-widest -mt-1">
                PORTFOLIO / 2026
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 p-1.5 rounded-full bg-white/[0.03] border border-white/10 backdrop-blur-md">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider transition-colors duration-200 ${
                    isActive ? 'text-white font-bold' : 'text-muted-grey hover:text-soft-white'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNavTab"
                      className="absolute inset-0 bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] rounded-full shadow-neon-red"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2.5">
            {/* Audio Toggle */}
            <button
              onClick={toggleSound}
              title={soundOn ? 'Mute Interface Sound' : 'Enable Futuristic Audio'}
              className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all ${
                soundOn
                  ? 'border-[#FF1744] text-[#FF1744] bg-[#FF1744]/10 shadow-neon-red'
                  : 'border-white/10 text-muted-grey hover:text-white bg-white/5'
              }`}
            >
              {soundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Resume Button */}
            <button
              onClick={() => {
                playSound('click');
                onOpenResume();
              }}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wider bg-white/10 hover:bg-[#FF1744] hover:text-white text-soft-white border border-white/15 hover:border-[#FF1744] shadow-sm hover:shadow-neon-red transition-all duration-300"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>RESUME</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => {
                playSound('click');
                setIsOpen(!isOpen);
              }}
              className="lg:hidden w-10 h-10 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center text-soft-white hover:text-[#FF1744]"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-30 pt-20 px-6 pb-8 bg-[#050505]/98 backdrop-blur-2xl flex flex-col justify-between lg:hidden border-b border-white/10"
          >
            <div className="flex flex-col gap-2.5">
              <div className="text-[11px] font-mono tracking-widest text-[#FF1744] border-b border-white/10 pb-2 mb-2">
                NAVIGATION MATRIX // PORTFOLIO 2026
              </div>

              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center justify-between p-3 rounded-xl text-left font-heading text-base font-bold tracking-wide transition-colors ${
                    activeSection === item.id
                      ? 'bg-[#FF1744]/15 text-[#FF1744] border border-[#FF1744]/30'
                      : 'text-muted-grey hover:text-soft-white hover:bg-white/5'
                  }`}
                >
                  <span>{item.label}</span>
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </button>
              ))}

              <button
                onClick={() => {
                  playSound('click');
                  setIsOpen(false);
                  onOpenResume();
                }}
                className="mt-4 flex items-center justify-center gap-2 p-3.5 rounded-xl font-mono text-sm font-bold bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] text-white shadow-neon-red"
              >
                <FileText className="w-4 h-4" />
                <span>DOWNLOAD OFFICIAL RESUME</span>
              </button>
            </div>

            <div className="pt-6 border-t border-white/10 flex items-center justify-between text-xs font-mono text-muted-grey">
              <span>A. NETHAJI // TAMIL NADU</span>
              <span className="text-[#FF1744]">+91 7603892617</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

