import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Cpu, Flame, Target, BookOpen, User, CheckCircle2, ShieldCheck } from 'lucide-react';

export default function About() {
  const pillars = [
    {
      icon: Brain,
      title: 'CREATIVE PROBLEM SOLVING',
      desc: 'Approaching challenges not just as code syntax, but as end-to-end user experience opportunities with logical precision and inventive thinking.',
      badge: 'CORE COMPETENCY'
    },
    {
      icon: Cpu,
      title: 'AI-ASSISTED VIBE CODING',
      desc: 'Harnessing modern AI-assisted engineering (Lovable, Antigravity) to rapidly prototype and iterate production-grade digital architectures.',
      badge: 'MODERN WORKFLOW'
    },
    {
      icon: Flame,
      title: 'CINEMATIC WEB EXPERIENCES',
      desc: 'Merging flawless responsive functionality with high-impact aesthetics, interactive 3D WebGL graphics, and cinematic micro-interactions.',
      badge: 'DESIGN PHILOSOPHY'
    },
    {
      icon: Target,
      title: 'CAREER OBJECTIVE',
      desc: 'To become a skilled software developer by applying programming knowledge, web development skills, and emerging AI technologies while continuously growing professionally.',
      badge: 'STRATEGIC VISION'
    }
  ];

  return (
    <section id="about" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <User className="w-4 h-4" />
          <span>ABOUT A. NETHAJI // ARCHITECTURE & BIOGRAPHY</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          BEHIND THE <span className="text-gradient-cinematic">CODE.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Meet the developer, the philosophy, and the relentless curiosity driving modern software solutions.
        </motion.p>
      </div>

      {/* Split-Screen Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Left Side: Profile Dossier & Frame */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="lg:col-span-5 rounded-2xl p-6 sm:p-8 bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-[#FF1744]/30 backdrop-blur-xl shadow-glass-card flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
              <span className="text-xs font-mono tracking-widest text-[#FF1744]">IDENTITY VERIFIED</span>
              <span className="text-xs font-mono text-[#D4AF37]">PORTFOLIO / 2026</span>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-[#FF1744] shadow-neon-red shrink-0">
                <img
                  src="/profile.jpg"
                  alt="A. Nethaji"
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div>
                <h3 className="text-2xl font-black font-heading text-white">
                  A. NETHAJI
                </h3>
                <p className="text-xs font-mono text-[#D4AF37] font-semibold mt-0.5">
                  SOFTWARE DEVELOPER // BCA STUDENT
                </p>
                <div className="text-[11px] font-mono text-muted-grey mt-1">
                  Tamil Nadu, India
                </div>
              </div>
            </div>

            <p className="text-soft-white/90 text-sm leading-relaxed mb-4">
              Motivated Bachelor of Computer Applications (BCA) student with a strong foundation in computer applications, programming, and web development. Interested in building useful digital solutions, applying technical and AI-assisted development skills, and continuously learning and growing in software development.
            </p>

            <p className="text-muted-grey text-sm leading-relaxed mb-6">
              Serving as a Full Stack Developer Intern at Arumexa Technology Private Limited, contributing to full-stack website development, software tasks, and AI-assisted development (Vibe Coding).
            </p>

            {/* Dossier Attributes */}
            <div className="space-y-3 pt-4 border-t border-white/10 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-muted-grey">DEGREE:</span>
                <span className="text-white font-semibold">BCA (2024–2027)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-grey">INSTITUTION:</span>
                <span className="text-[#D4AF37] font-semibold">Kalasalingam Academy</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-grey">INDUSTRY ROLE:</span>
                <span className="text-[#FF1744] font-semibold">Full Stack Intern @ Arumexa Tech</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-grey">METHODOLOGY:</span>
                <span className="text-[#FF6A00] font-semibold">AI-Assisted Vibe Coding</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-white/10 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#FF1744]/20 border border-[#FF1744] flex items-center justify-center text-[#FF1744]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-white">GENUINE RESUME DOSSIER</div>
              <div className="text-[11px] font-mono text-muted-grey">Verified Credentials & Production Implementation</div>
            </div>
          </div>
        </motion.div>

        {/* Right Side: Philosophy & Objectives Grid */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
          {pillars.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group p-6 rounded-2xl bg-[#111111]/85 hover:bg-[#161616] border border-white/10 hover:border-[#FF1744]/50 backdrop-blur-md transition-all duration-300 hover:-translate-y-1 shadow-md hover:shadow-neon-red flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-black/60 border border-white/10 flex items-center justify-center text-[#FF1744] group-hover:scale-110 group-hover:bg-[#FF1744] group-hover:text-white transition-all duration-300">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[#D4AF37]">
                      {item.badge}
                    </span>
                  </div>

                  <h4 className="text-lg font-bold font-heading text-white mb-2 tracking-wide group-hover:text-[#F5D77B] transition-colors">
                    {item.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-muted-grey leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-muted-grey group-hover:text-[#FF1744] transition-colors">
                  <span>PILLAR 0{idx + 1}</span>
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity">● ACTIVE</span>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}

