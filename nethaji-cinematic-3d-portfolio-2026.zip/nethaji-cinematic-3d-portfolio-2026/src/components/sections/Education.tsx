import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Calendar, MapPin, BookCheck } from 'lucide-react';

export default function Education() {
  const educations = [
    {
      period: '2024–2027',
      degree: 'Bachelor of Computer Applications (BCA)',
      institution: 'Kalasalingam Academy of Research and Education',
      type: 'Deemed to be University',
      location: 'Krishnankoil, Tamil Nadu, India',
      status: 'CURRENTLY PURSUING // ACTIVE',
      color: 'border-[#FF1744] text-[#FF1744]',
      bgGlow: 'from-[#FF1744]/20 to-transparent',
      highlights: [
        'Core curriculum in Computer Applications, Software Architecture, and Web Development',
        'Practical labs in Object-Oriented Programming, Data Structures, and Database Management',
        'Specialization in AI-Assisted Modern Web Technologies and Digital Solutions'
      ]
    },
    {
      period: '2022–2024',
      degree: 'Higher Secondary Education (Class XII)',
      institution: 'TNPM Marimuthu Nadar Higher Secondary School',
      type: 'Higher Secondary State Board',
      location: 'Thalaivapuram, Tamil Nadu, India',
      status: 'COMPLETED // STRONG FOUNDATION',
      color: 'border-[#D4AF37] text-[#D4AF37]',
      bgGlow: 'from-[#D4AF37]/20 to-transparent',
      highlights: [
        'Rigorous coursework in Mathematics, Physical Sciences, and Analytical Reasoning',
        'Cultivated foundational passion for programming logic and computational problem solving',
        'Graduated with distinction qualifying for BCA degree studies at Kalasalingam Academy'
      ]
    }
  ];

  return (
    <section id="education" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <GraduationCap className="w-4 h-4" />
          <span>ACADEMIC FOUNDATION // TIMELINE</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          ACADEMIC <span className="text-gradient-cinematic">EDUCATION.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Academic trajectory providing the theoretical principles, mathematical logic, and computational disciplines behind modern software development.
        </motion.p>
      </div>

      {/* Timeline Content */}
      <div className="relative max-w-4xl mx-auto">
        {/* Central Glowing Laser Line */}
        <div className="absolute top-0 bottom-0 left-4 sm:left-1/2 -translate-x-1/2 w-[2px] bg-gradient-to-b from-[#FF1744] via-[#FF6A00] to-[#D4AF37] opacity-60 shadow-neon-red" />

        <div className="space-y-12">
          {educations.map((edu, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className={`relative flex flex-col ${
                idx % 2 === 0 ? 'sm:flex-row' : 'sm:flex-row-reverse'
              } items-center gap-8`}
            >
              {/* Timeline Center Node */}
              <div className="absolute left-4 sm:left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-[#050505] border-2 border-[#FF1744] shadow-neon-red flex items-center justify-center z-10">
                <div className="w-2 h-2 rounded-full bg-[#D4AF37] animate-ping" />
              </div>

              {/* Card Container */}
              <div className="w-full sm:w-[calc(50%-2rem)] pl-12 sm:pl-0">
                <div className="relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#161214]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#FF1744]/60 backdrop-blur-xl shadow-glass-card hover:shadow-neon-red transition-all duration-300 group">
                  {/* Glowing background gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${edu.bgGlow} rounded-2xl opacity-20 pointer-events-none`} />

                  {/* Header Meta */}
                  <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-3">
                    <span className="flex items-center gap-1.5 text-xs font-mono text-[#D4AF37] font-bold">
                      <Calendar className="w-3.5 h-3.5 text-[#FF1744]" />
                      {edu.period}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-muted-grey">
                      {edu.status}
                    </span>
                  </div>

                  {/* Degree Name */}
                  <h3 className="text-xl sm:text-2xl font-bold font-heading text-white group-hover:text-[#F5D77B] transition-colors mb-2">
                    {edu.degree}
                  </h3>

                  {/* Institution */}
                  <div className="text-sm font-semibold text-[#FF1744] mb-1 font-heading">
                    {edu.institution}
                  </div>
                  <div className="text-xs font-mono text-muted-grey mb-3">
                    {edu.type}
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-mono text-muted-grey mb-5">
                    <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{edu.location}</span>
                  </div>

                  {/* Highlights */}
                  <div className="space-y-2 pt-3 border-t border-white/10">
                    {edu.highlights.map((item, hIdx) => (
                      <div key={hIdx} className="flex items-start gap-2 text-xs text-soft-white/85">
                        <BookCheck className="w-3.5 h-3.5 text-[#D4AF37] mt-0.5 shrink-0" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Empty placeholder for balance on desktop */}
              <div className="hidden sm:block sm:w-[calc(50%-2rem)]" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

