import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Code2, 
  Palette, 
  Lightbulb, 
  Cpu, 
  Kanban, 
  Clock, 
  Users, 
  Layers, 
  Wrench, 
  Zap,
  Terminal,
  FileCode2,
  CheckCircle2
} from 'lucide-react';
import { playSound } from '../../utils/audio';

interface SkillItem {
  name: string;
  category: 'Programming' | 'Web Development' | 'AI & Innovation' | 'Professional';
  icon: React.ElementType;
  description: string;
  highlight: string;
  technologies: string[];
}

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const skillsList: SkillItem[] = [
    {
      name: 'Web Development & Design',
      category: 'Web Development',
      icon: Code2,
      description: 'Building responsive, high-performance web applications using modern component architecture, clean semantics, and glassmorphic aesthetics.',
      highlight: 'Core Competency',
      technologies: ['HTML5', 'CSS3', 'JavaScript (ES6+)', 'React', 'TypeScript', 'Tailwind CSS']
    },
    {
      name: 'Programming Fundamentals',
      category: 'Programming',
      icon: Terminal,
      description: 'Solid computer science foundations across object-oriented programming, algorithmic structures, logic building, and system operations.',
      highlight: 'CS Foundation',
      technologies: ['Python', 'Java', 'C', 'C++', 'Data Structures', 'OOP']
    },
    {
      name: 'AI-Assisted Development (Vibe Coding)',
      category: 'AI & Innovation',
      icon: Cpu,
      description: 'Harnessing cutting-edge AI pair programming, prompt design, and iterative vibe coding to accelerate prototyping and feature implementation.',
      highlight: 'Next-Gen Workflow',
      technologies: ['Vibe Coding', 'Lovable AI', 'Antigravity AI', 'Prompt Engineering', 'Rapid Prototyping']
    },
    {
      name: 'Creative Problem-Solving',
      category: 'Programming',
      icon: Lightbulb,
      description: 'Deconstructing complex engineering bottlenecks into modular, elegant, maintainable, and verifiable software algorithms.',
      highlight: 'Logical Precision',
      technologies: ['Root Cause Analysis', 'Algorithmic Logic', 'Debugging', 'Optimization']
    },
    {
      name: 'Full Stack Architecture',
      category: 'Web Development',
      icon: Zap,
      description: 'Hands-on full-stack development experience gained during industry internship at Arumexa Technology Private Limited.',
      highlight: 'Industry Exposure',
      technologies: ['Frontend UI', 'API Integration', 'Full Stack Workflows', 'Responsive Systems']
    },
    {
      name: 'Website Design & UI/UX',
      category: 'Web Development',
      icon: Palette,
      description: 'Crafting dark cinematic layouts, cybernetic HUD elements, harmonious color palettes, fluid typography, and interactive 3D elements.',
      highlight: 'Visual Harmony',
      technologies: ['UI/UX Design', 'Glassmorphism', 'Cyberpunk Palette', 'Micro-interactions', 'Spacing']
    },
    {
      name: 'Project Planning & Execution',
      category: 'Professional',
      icon: Kanban,
      description: 'Structuring project roadmaps, defining milestones, managing deadlines, and executing delivery pipelines systematically.',
      highlight: 'Structured Delivery',
      technologies: ['Milestone Roadmaps', 'Execution Discipline', 'Scope Management', 'Delivery Pipelines']
    },
    {
      name: 'Team Collaboration & Agility',
      category: 'Professional',
      icon: Users,
      description: 'Cross-functional communication, code review participation, and collaborative problem-solving within development teams.',
      highlight: 'Synergy & Growth',
      technologies: ['Cross-functional Sync', 'Version Control Habits', 'Constructive Feedback', 'Agile Mindset']
    },
    {
      name: 'Time Management',
      category: 'Professional',
      icon: Clock,
      description: 'Prioritizing critical paths, meeting academic and internship goals, and maintaining development velocity under sprint deadlines.',
      highlight: 'Sprint Discipline',
      technologies: ['Sprint Cycles', 'Deadline Discipline', 'Focus Management', 'Resource Efficiency']
    }
  ];

  const categories = ['All', 'Web Development', 'Programming', 'AI & Innovation', 'Professional'];

  const filteredSkills = activeCategory === 'All' 
    ? skillsList 
    : skillsList.filter(s => s.category === activeCategory);

  return (
    <section id="skills" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <Wrench className="w-4 h-4" />
          <span>TECHNICAL & PROFESSIONAL CAPABILITIES</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          TECHNICAL <span className="text-gradient-cinematic">SKILLS.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          A comprehensive skillset verified by academic rigor and industry internship — spanning languages, modern frameworks, and AI workflows.
        </motion.p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              playSound('click');
              setActiveCategory(cat);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-mono tracking-wide transition-all duration-300 ${
              activeCategory === cat
                ? 'bg-gradient-to-r from-[#FF1744] to-[#FF6A00] text-white font-bold shadow-neon-red scale-105'
                : 'bg-[#111111]/85 hover:bg-[#1A1A1A] text-muted-grey hover:text-white border border-white/10'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Skill Cards Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredSkills.map((skill, index) => {
          const Icon = skill.icon;
          return (
            <motion.div
              layout
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="group relative p-6 rounded-2xl bg-gradient-to-b from-[#181112]/90 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#FF1744]/60 backdrop-blur-xl shadow-glass-card hover:shadow-neon-red transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Header with Icon & Category */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-black/60 border border-[#FF1744]/30 flex items-center justify-center text-[#FF1744] group-hover:bg-[#FF1744] group-hover:text-white transition-colors duration-300">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[#D4AF37]">
                    {skill.category}
                  </span>
                </div>

                {/* Skill Name */}
                <h3 className="text-xl font-bold font-heading text-white group-hover:text-[#F5D77B] transition-colors mb-2">
                  {skill.name}
                </h3>

                {/* Description */}
                <p className="text-muted-grey text-xs sm:text-sm leading-relaxed mb-5">
                  {skill.description}
                </p>

                {/* Highlight Badge */}
                <div className="mb-4 inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#FF1744]/10 border border-[#FF1744]/25 text-[#FF1744] text-[11px] font-mono font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{skill.highlight}</span>
                </div>
              </div>

              {/* Verified Tool Badges */}
              <div className="pt-4 border-t border-white/10">
                <div className="flex flex-wrap gap-1.5">
                  {skill.technologies.map((tech, tIdx) => (
                    <span
                      key={tIdx}
                      className="px-2 py-0.5 rounded text-[11px] font-mono bg-white/[0.04] text-soft-white/80 border border-white/5 group-hover:border-white/15"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Glowing Corner Accents */}
              <div className="absolute top-0 right-0 w-8 h-8 rounded-tr-2xl border-t border-r border-transparent group-hover:border-[#FF1744] transition-colors pointer-events-none" />
            </motion.div>
          );
        })}
      </motion.div>
    </section>
  );
}

