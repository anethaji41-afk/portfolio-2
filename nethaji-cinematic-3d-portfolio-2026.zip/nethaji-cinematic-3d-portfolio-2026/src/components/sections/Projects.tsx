import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, FolderGit2, ShieldAlert, GraduationCap, Mic, ArrowUpRight, CheckCircle2, Sparkles } from 'lucide-react';
import { playSound } from '../../utils/audio';

interface ProjectItem {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  url: string;
  icon: React.ElementType;
  tags: string[];
  features: string[];
  gradient: string;
  badge: string;
  accentColor: string;
}

export default function Projects() {
  const projects: ProjectItem[] = [
    {
      id: 'eduai-friend',
      number: 'PROJECT 01',
      title: 'EDUAI FRIEND',
      tagline: 'AI-POWERED DAILY STUDY COMPANION',
      description: 'A web-based educational platform designed to help students understand complex topics, prepare for examinations, organize study schedules, and access suitable learning resources through personalized learning support.',
      url: 'https://eduai-friend.lovable.app',
      icon: GraduationCap,
      tags: ['AI Learning Assistant', 'Web Platform', 'Adaptive Scheduling', 'Student Dashboard', 'Prompt Intelligence'],
      features: [
        'Personalized daily study schedule generator',
        'Complex syllabus topic breakdown and summaries',
        'Examination preparation & question bank support',
        'Curated educational learning resource recommendations'
      ],
      gradient: 'from-[#FF1744]/20 via-[#FF6A00]/10 to-transparent',
      badge: 'LIVE WEB APPLICATION',
      accentColor: '#FF1744'
    },
    {
      id: 'fake-job-detection',
      number: 'PROJECT 02',
      title: 'AI-BASED FAKE JOB & INTERNSHIP DETECTION SYSTEM',
      tagline: 'FRAUD & SCAM PREVENTATIVE DECISION SUPPORT',
      description: 'A web-based decision-support system designed to help students and job seekers identify potentially fraudulent job postings and internship offers by highlighting warning signs such as suspicious links, registration fees, unrealistic salary promises, and requests for sensitive personal information.',
      url: 'https://anethaji41-afk.github.io/AI-Based-Fake-Job-and-Internship-Detection-System/',
      icon: ShieldAlert,
      tags: ['Cybersecurity', 'Fraud Prevention', 'Risk Scoring', 'Decision Support', 'GitHub Pages'],
      features: [
        'Real-time job & internship posting risk score analysis',
        'Registration fee & upfront monetary scam red flags',
        'Suspicious URL and phishing link checker',
        'Sensitive personal identity extraction prevention'
      ],
      gradient: 'from-[#FF6A00]/20 via-[#FF1744]/10 to-transparent',
      badge: 'LIVE PRODUCTION TOOL',
      accentColor: '#FF6A00'
    },
    {
      id: 'digital-friend',
      number: 'PROJECT 03',
      title: 'DIGITAL FRIEND',
      tagline: 'AI-POWERED VOICE COMPANION',
      description: 'An AI-powered voice companion application designed to provide users with an interactive and intelligent communication experience. A digital assistant that allows users to communicate with an AI system through a user-friendly interface and voice-based interactions, making human-computer interaction natural, accessible, and convenient.',
      url: 'https://digital-friend-voice.lovable.app',
      icon: Mic,
      tags: ['Voice AI', 'Speech Synthesis', 'Conversational AI', 'Interactive Audio HUD', 'Lovable App'],
      features: [
        'Real-time voice-based conversational interaction',
        'Intelligent contextual response generation',
        'Natural, accessible, and convenient user interface',
        'Demonstrates conversational AI in daily human interaction'
      ],
      gradient: 'from-[#D4AF37]/20 via-[#FF1744]/10 to-transparent',
      badge: 'LIVE VOICE COMPANION',
      accentColor: '#D4AF37'
    }
  ];

  return (
    <section id="projects" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <FolderGit2 className="w-4 h-4" />
          <span>PROJECT SHOWCASE // PRODUCTION APPLICATIONS</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          SELECTED <span className="text-gradient-cinematic">WORKS.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Real, deployed web platforms engineered with focus on user empowerment, cyber safety, and intelligent conversational AI.
        </motion.p>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
        {projects.map((project, idx) => {
          const Icon = project.icon;
          return (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.15 }}
              whileHover={{ y: -8 }}
              className="group relative rounded-3xl p-6 sm:p-7 bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#FF1744]/70 backdrop-blur-xl shadow-glass-card hover:shadow-neon-red transition-all duration-500 flex flex-col justify-between overflow-hidden"
            >
              {/* Background Ambient Glow */}
              <div className={`absolute top-0 right-0 w-80 h-80 bg-gradient-to-br ${project.gradient} rounded-full blur-3xl -z-10 opacity-30 group-hover:opacity-70 transition-opacity duration-500 pointer-events-none`} />

              <div>
                {/* Header Meta: Number & Badge */}
                <div className="flex items-center justify-between mb-5 pb-3 border-b border-white/10">
                  <span className="text-xs font-mono font-bold tracking-widest text-[#FF1744]">
                    {project.number}
                  </span>
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-white/5 border border-white/10 text-[#D4AF37]">
                    {project.badge}
                  </span>
                </div>

                {/* 3D Preview Frame / Icon Banner */}
                <div className="relative w-full h-44 rounded-2xl bg-black/70 border border-white/10 mb-6 flex items-center justify-center overflow-hidden scanline group-hover:border-[#FF1744]/50 transition-colors">
                  <div className="absolute inset-0 bg-cyber-grid opacity-30" />
                  
                  {/* Glowing center emblem */}
                  <div className="relative z-10 w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#FF1744]/20 via-[#FF6A00]/20 to-[#D4AF37]/20 border border-[#FF1744]/40 flex items-center justify-center text-[#FF1744] group-hover:scale-110 group-hover:border-[#FF1744] transition-transform duration-500">
                    <Icon className="w-10 h-10" />
                  </div>

                  {/* Corner Accent Brackets */}
                  <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-[#FF1744]" />
                  <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-[#D4AF37]" />
                  <div className="absolute bottom-2 left-2 w-3 h-3 border-b border-l border-[#D4AF37]" />
                  <div className="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-[#FF1744]" />
                </div>

                {/* Project Title & Tagline */}
                <h3 className="text-2xl font-black font-heading text-white group-hover:text-[#F5D77B] transition-colors leading-tight mb-2">
                  {project.title}
                </h3>
                <div className="text-xs font-mono text-[#D4AF37] font-semibold uppercase tracking-wider mb-4">
                  {project.tagline}
                </div>

                {/* Description */}
                <p className="text-muted-grey text-xs sm:text-sm leading-relaxed mb-6">
                  {project.description}
                </p>

                {/* Key Capabilities */}
                <div className="space-y-2 mb-6 p-4 rounded-xl bg-black/50 border border-white/5">
                  <div className="text-[10px] font-mono tracking-widest text-[#FF1744] uppercase mb-1">
                    KEY CAPABILITIES
                  </div>
                  {project.features.map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-2 text-xs text-soft-white/85">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#FF1744] mt-0.5 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mb-8">
                  {project.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="px-2.5 py-1 rounded text-xs font-mono bg-white/[0.03] border border-white/10 text-muted-grey hover:text-white hover:border-[#FF1744]/30 transition-colors"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div>
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => playSound('click')}
                  className="w-full py-3.5 px-6 rounded-xl font-mono text-xs sm:text-sm tracking-wider font-bold text-white bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] shadow-neon-red flex items-center justify-center gap-2 transition-all duration-300 hover:scale-[1.02] active:scale-95"
                >
                  <span>VIEW PROJECT ONLINE</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

