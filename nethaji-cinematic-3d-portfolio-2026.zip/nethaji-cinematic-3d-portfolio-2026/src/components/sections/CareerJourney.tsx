import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import CareerJourneyMap, { MILESTONES, MilestoneData } from '../canvas/CareerJourneyMap';
import { Compass, ArrowRight, ShieldCheck, Award } from 'lucide-react';
import { playSound } from '../../utils/audio';

export default function CareerJourney() {
  const [activeMilestone, setActiveMilestone] = useState<MilestoneData>(MILESTONES[2]); // Default on Stage 03 (Arumexa Internship)

  const handleSelectStage = (m: MilestoneData) => {
    playSound('toggle');
    setActiveMilestone(m);
  };

  return (
    <section id="journey" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <Compass className="w-4 h-4 animate-spin-slow" />
          <span>CAREER MAPPING SYSTEM // 3D INTERACTIVE</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          CAREER <span className="text-gradient-cinematic">JOURNEY.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Explore the interactive 3D planetary map tracing academic foundations, industry internship at Arumexa Technology, and future engineering milestones.
        </motion.p>
      </div>

      {/* Stage Selector Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-4 mb-10">
        {MILESTONES.map((m) => {
          const isSelected = activeMilestone.id === m.id;
          return (
            <button
              key={m.id}
              onClick={() => handleSelectStage(m)}
              className={`group flex items-center gap-2 px-4 py-2.5 rounded-xl font-mono text-xs sm:text-sm tracking-wide transition-all duration-300 ${
                isSelected
                  ? 'bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] text-white font-bold shadow-neon-red scale-105'
                  : 'bg-[#111111]/85 hover:bg-[#1A1A1A] text-muted-grey hover:text-white border border-white/10'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${
                m.status === 'completed'
                  ? 'bg-[#D4AF37]'
                  : m.status === 'in-progress'
                  ? 'bg-[#FF1744] animate-ping'
                  : 'bg-muted-grey'
              }`} />
              <span>{m.stage}</span>
              <span className="hidden md:inline opacity-75">({m.year})</span>
            </button>
          );
        })}
      </div>

      {/* Main 3D Experience Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Column: 3D Planetary Career Map */}
        <div className="lg:col-span-7 w-full">
          <CareerJourneyMap
            activeMilestone={activeMilestone}
            onSelectMilestone={handleSelectStage}
          />
        </div>

        {/* Right Column: Holographic Information HUD Panel */}
        <div className="lg:col-span-5 w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeMilestone.id}
              initial={{ opacity: 0, x: 25 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -25 }}
              transition={{ duration: 0.4 }}
              className="relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 backdrop-blur-xl border border-[#FF1744]/35 shadow-glass-card"
            >
              {/* Top Meta Status */}
              <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-3">
                <span className="text-[11px] font-mono tracking-widest text-[#FF1744] flex items-center gap-1.5 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {activeMilestone.statusLabel}
                </span>
                <span className="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-white/5 border border-white/10 text-[#D4AF37]">
                  {activeMilestone.year}
                </span>
              </div>

              {/* Title & Organization */}
              <h3 className="text-2xl sm:text-3xl font-extrabold font-heading text-white leading-tight mb-2">
                {activeMilestone.title}
              </h3>
              <p className="text-sm font-mono text-[#D4AF37] mb-4 flex items-center gap-1.5 font-semibold">
                <Award className="w-4 h-4 text-[#FF1744]" />
                {activeMilestone.institution}
              </p>

              {/* Description */}
              <p className="text-muted-grey text-sm leading-relaxed mb-6">
                {activeMilestone.description}
              </p>

              {/* Deep Details */}
              <div className="p-3.5 rounded-xl bg-black/60 border border-white/5 mb-6 text-xs text-soft-white/90 leading-relaxed font-sans">
                {activeMilestone.details}
              </div>

              {/* Unlocked Competencies */}
              <div>
                <div className="text-[11px] font-mono tracking-widest text-muted-grey uppercase mb-2.5">
                  CORE COMPETENCIES & MILESTONE IMPACT
                </div>
                <div className="flex flex-wrap gap-2">
                  {activeMilestone.skills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-md text-xs font-mono bg-[#FF1744]/10 border border-[#FF1744]/25 text-white hover:border-[#FF1744] transition-colors"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Status Footer */}
              <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
                <div className="text-[11px] font-mono text-muted-grey">
                  STATUS: <span className="text-[#FF1744] uppercase font-bold">{activeMilestone.status}</span>
                </div>
                <button
                  onClick={() => {
                    const nextId = (activeMilestone.id % 4) + 1;
                    const nextM = MILESTONES.find(m => m.id === nextId) || MILESTONES[0];
                    handleSelectStage(nextM);
                  }}
                  className="inline-flex items-center gap-1 text-xs font-mono text-[#D4AF37] hover:text-white transition-colors"
                >
                  NEXT NODE <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

