import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, CheckCircle2, Copy, MessageSquare, ExternalLink } from 'lucide-react';
import { playSound } from '../../utils/audio';

export default function Contact() {
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', subject: 'Collaboration Opportunity', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const copyToClipboard = (text: string, type: string) => {
    playSound('click');
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!formData.name.trim()) errs.name = 'Please provide your name or organization.';
    if (!formData.email.trim()) {
      errs.email = 'Please provide a valid email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Please enter a valid email format (e.g. name@domain.com).';
    }
    if (!formData.message.trim() || formData.message.trim().length < 10) {
      errs.message = 'Please enter a message with at least 10 characters.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      playSound('toggle');
      return;
    }

    playSound('success');
    setSubmitted(true);

    // Open user's default email client with prepopulated transmission
    const subject = encodeURIComponent(`[Portfolio 2026] ${formData.subject} - from ${formData.name}`);
    const body = encodeURIComponent(
      `Hello Nethaji,\n\nName: ${formData.name}\nEmail: ${formData.email}\nSubject: ${formData.subject}\n\nMessage:\n${formData.message}\n\nSent from your 3D Cinematic Portfolio.`
    );
    window.location.href = `mailto:anethaji41@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <section id="contact" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <MessageSquare className="w-4 h-4" />
          <span>COMMUNICATION RELAY // INITIATE TRANSMISSION</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-black font-heading tracking-tight leading-[1.05]"
        >
          HAVE AN IDEA? <br />
          <span className="text-gradient-cinematic">LET'S BUILD IT.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Interested in software development, full-stack internships, AI-assisted engineering, or building innovative web systems? Reach out through any direct channel.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Direct Transmission Channels */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Email Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="p-6 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#FF1744]/60 backdrop-blur-xl shadow-glass-card group transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono tracking-widest text-[#FF1744] uppercase font-bold">OFFICIAL EMAIL</span>
              <button
                onClick={() => copyToClipboard('anethaji41@gmail.com', 'email')}
                className="text-xs font-mono text-[#D4AF37] hover:text-white flex items-center gap-1 transition-colors"
              >
                {copiedType === 'email' ? (
                  <span className="text-[#FF1744] flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" /> COPIED!
                  </span>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> COPY
                  </>
                )}
              </button>
            </div>
            
            <a
              href="mailto:anethaji41@gmail.com"
              onClick={() => playSound('click')}
              className="flex items-center gap-4 text-white hover:text-[#FF1744] transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-[#FF1744]/10 border border-[#FF1744]/30 flex items-center justify-center text-[#FF1744] group-hover:scale-110 group-hover:bg-[#FF1744] group-hover:text-white transition-all">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <div className="text-lg font-bold font-heading text-white group-hover:text-[#F5D77B] transition-colors">
                  anethaji41@gmail.com
                </div>
                <div className="text-xs font-mono text-muted-grey">Click to compose email</div>
              </div>
            </a>
          </motion.div>

          {/* Phone Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="p-6 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#D4AF37]/60 backdrop-blur-xl shadow-glass-card group transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono tracking-widest text-[#D4AF37] uppercase font-bold">VOICE TELEPHONE</span>
              <button
                onClick={() => copyToClipboard('+917603892617', 'phone')}
                className="text-xs font-mono text-[#D4AF37] hover:text-white flex items-center gap-1 transition-colors"
              >
                {copiedType === 'phone' ? (
                  <span className="text-[#FF1744] flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" /> COPIED!
                  </span>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> COPY
                  </>
                )}
              </button>
            </div>

            <a
              href="tel:+917603892617"
              onClick={() => playSound('click')}
              className="flex items-center gap-4 text-white hover:text-[#D4AF37] transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] group-hover:scale-110 group-hover:bg-[#D4AF37] group-hover:text-black transition-all">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <div className="text-lg font-bold font-heading text-white group-hover:text-[#F5D77B] transition-colors">
                  +91 76038 92617
                </div>
                <div className="text-xs font-mono text-muted-grey">Click to dial call</div>
              </div>
            </a>
          </motion.div>

          {/* Location Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 backdrop-blur-xl shadow-glass-card flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white">
              <MapPin className="w-6 h-6 text-[#FF1744]" />
            </div>
            <div>
              <div className="text-xs font-mono text-muted-grey uppercase tracking-wider">GEOGRAPHIC BASE</div>
              <div className="text-base font-bold font-heading text-white">
                Tamil Nadu, India
              </div>
              <div className="text-xs font-mono text-[#D4AF37]">Available for Remote & On-site Roles</div>
            </div>
          </motion.div>

        </div>

        {/* Right Column: Validated Cyber Transmission Form */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-[#FF1744]/40 backdrop-blur-xl shadow-glass-card"
        >
          <div className="flex items-center justify-between mb-6 border-b border-white/10 pb-4">
            <span className="text-xs font-mono tracking-widest text-[#FF1744] font-bold">TRANSMISSION RELAY</span>
            <span className="text-xs font-mono text-muted-grey">SECURE EMAIL CLIENT DISPATCH</span>
          </div>

          {submitted ? (
            <div className="p-8 rounded-xl bg-[#FF1744]/10 border border-[#FF1744]/40 text-center space-y-4">
              <CheckCircle2 className="w-12 h-12 text-[#FF1744] mx-auto animate-bounce" />
              <h4 className="text-2xl font-bold font-heading text-white">TRANSMISSION DISPATCHED</h4>
              <p className="text-sm text-muted-grey max-w-md mx-auto">
                Your email client has been prepared with your message directly routed to <span className="text-[#FF1744] font-mono">anethaji41@gmail.com</span>.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2.5 rounded-xl font-mono text-xs bg-white/10 hover:bg-white/20 text-white border border-white/15 transition-colors"
              >
                SEND ANOTHER MESSAGE
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-muted-grey mb-2">
                  YOUR NAME / ORGANIZATION <span className="text-[#FF1744]">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Alex Morgan / Tech Team"
                  value={formData.name}
                  onChange={(e) => {
                    setFormData({ ...formData, name: e.target.value });
                    if (errors.name) setErrors({ ...errors, name: '' });
                  }}
                  className={`w-full px-4 py-3 rounded-xl bg-black/60 border ${
                    errors.name ? 'border-[#FF1744]' : 'border-white/15'
                  } focus:border-[#FF1744] focus:ring-1 focus:ring-[#FF1744] text-white text-sm outline-none transition-colors font-sans`}
                />
                {errors.name && <p className="text-xs text-[#FF1744] mt-1 font-mono">{errors.name}</p>}
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-muted-grey mb-2">
                  YOUR EMAIL ADDRESS <span className="text-[#FF1744]">*</span>
                </label>
                <input
                  type="email"
                  placeholder="e.g. alex@example.com"
                  value={formData.email}
                  onChange={(e) => {
                    setFormData({ ...formData, email: e.target.value });
                    if (errors.email) setErrors({ ...errors, email: '' });
                  }}
                  className={`w-full px-4 py-3 rounded-xl bg-black/60 border ${
                    errors.email ? 'border-[#FF1744]' : 'border-white/15'
                  } focus:border-[#FF1744] focus:ring-1 focus:ring-[#FF1744] text-white text-sm outline-none transition-colors font-sans`}
                />
                {errors.email && <p className="text-xs text-[#FF1744] mt-1 font-mono">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-muted-grey mb-2">
                  SUBJECT / TOPIC
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#FF1744] focus:ring-1 focus:ring-[#FF1744] text-white text-sm outline-none transition-colors font-sans"
                >
                  <option value="Full Stack Internship / Career Opportunity">Full Stack Internship / Career Opportunity</option>
                  <option value="Web Project Collaboration">Web Project Collaboration</option>
                  <option value="AI / Vibe Coding Innovation Discussion">AI / Vibe Coding Innovation Discussion</option>
                  <option value="General Technical Inquiry">General Technical Inquiry</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-muted-grey mb-2">
                  MESSAGE SCOPE <span className="text-[#FF1744]">*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="Tell me about your project, idea, or opportunity..."
                  value={formData.message}
                  onChange={(e) => {
                    setFormData({ ...formData, message: e.target.value });
                    if (errors.message) setErrors({ ...errors, message: '' });
                  }}
                  className={`w-full px-4 py-3 rounded-xl bg-black/60 border ${
                    errors.message ? 'border-[#FF1744]' : 'border-white/15'
                  } focus:border-[#FF1744] focus:ring-1 focus:ring-[#FF1744] text-white text-sm outline-none transition-colors font-sans resize-none`}
                />
                <div className="flex items-center justify-between mt-1">
                  {errors.message ? (
                    <p className="text-xs text-[#FF1744] font-mono">{errors.message}</p>
                  ) : <span />}
                  <span className="text-[11px] font-mono text-muted-grey">
                    {formData.message.length} characters
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl font-mono text-sm tracking-wider font-bold text-white bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] shadow-neon-red transition-all duration-300 hover:scale-[1.01] active:scale-98 flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>TRANSMIT DISPATCH</span>
                <Send className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </form>
          )}
        </motion.div>

      </div>
    </section>
  );
}

