import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, CheckCircle2, Code2, Cpu, Sparkles, Building2, Calendar, MapPin } from 'lucide-react';

export default function Experience() {
  const highlights = [
    {
      title: 'Full-Stack Website Development',
      desc: 'Collaborated with engineering teams on building responsive frontend interfaces, clean component structures, and modular software architectures.',
      icon: Code2
    },
    {
      title: 'AI-Assisted Development (Vibe Coding)',
      desc: 'Applied next-generation AI-assisted engineering tools and prompt design to streamline repetitive workflows, accelerate feature delivery, and test prototypes.',
      icon: Cpu
    },
    {
      title: 'Lovable & Antigravity Tooling',
      desc: 'Hands-on practice utilizing Lovable and Google Antigravity to explore rapid development cycles, automated pipelines, and intelligent code synthesis.',
      icon: Sparkles
    },
    {
      title: 'Creative Problem-Solving & Implementation',
      desc: 'Actively debugged bottlenecks, implemented responsive design solutions, and ensured high code maintainability and user accessibility.',
      icon: CheckCircle2
    }
  ];

  return (
    <section id="experience" className="relative py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      {/* Section Header */}
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <Briefcase className="w-4 h-4" />
          <span>INDUSTRY WORK // VERIFIED INTERNSHIP</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          PROFESSIONAL <span className="text-gradient-cinematic">EXPERIENCE.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Real-world industry exposure demonstrating practical software development, teamwork, and modern AI engineering.
        </motion.p>
      </div>

      {/* Main Experience Card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-4xl mx-auto p-6 sm:p-10 rounded-3xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-[#FF1744]/40 shadow-neon-red backdrop-blur-xl relative overflow-hidden group"
      >
        {/* Ambient Corner Glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-[#FF1744]/15 via-[#FF6A00]/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Information */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono bg-[#FF1744]/15 border border-[#FF1744]/30 text-[#FF1744] font-bold mb-2">
              <span className="w-2 h-2 rounded-full bg-[#FF1744] animate-ping" />
              INDUSTRY INTERNSHIP // VERIFIED
            </div>
            <h3 className="text-2xl sm:text-3xl font-black font-heading text-white">
              Full Stack Developer Intern
            </h3>
            <div className="text-base font-mono text-[#D4AF37] flex items-center gap-2 mt-1">
              <Building2 className="w-4 h-4 text-[#FF1744]" />
              <span>Arumexa Technology Private Limited</span>
            </div>
          </div>

          <div className="text-left sm:text-right space-y-1">
            <div className="text-xs font-mono text-muted-grey flex items-center sm:justify-end gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#FF6A00]" />
              <span>Internship Trajectory</span>
            </div>
            <div className="text-xs font-mono text-white/80 flex items-center sm:justify-end gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Tamil Nadu, India</span>
            </div>
          </div>
        </div>

        {/* Core Responsibilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {highlights.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-black/50 border border-white/5 hover:border-[#FF1744]/30 transition-colors"
              >
                <div className="flex items-center gap-3 mb-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#FF1744]/10 border border-[#FF1744]/30 flex items-center justify-center text-[#FF1744]">
                    <Icon className="w-4 h-4" />
                  </div>
                  <h4 className="text-sm font-bold font-heading text-white">
                    {item.title}
                  </h4>
                </div>
                <p className="text-xs text-muted-grey leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Verified Tools & Methodologies */}
        <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs font-mono text-muted-grey uppercase tracking-wider">
            TECHNOLOGY STACK & METHODOLOGY:
          </div>
          <div className="flex flex-wrap gap-2">
            {['Web Development', 'Software Tasks', 'AI-Assisted Dev', 'Vibe Coding', 'Lovable AI', 'Antigravity AI', 'Team Collaboration'].map((tag, tIdx) => (
              <span
                key={tIdx}
                className="px-3 py-1 rounded-lg text-xs font-mono bg-white/[0.04] border border-white/10 text-[#F5D77B]"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}

