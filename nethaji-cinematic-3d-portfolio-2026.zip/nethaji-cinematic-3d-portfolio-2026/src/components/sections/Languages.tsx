import React from 'react';
import { motion } from 'framer-motion';
import { Languages as LanguagesIcon, Volume2, Globe2 } from 'lucide-react';

export default function Languages() {
  const languageList = [
    {
      name: 'TAMIL',
      level: 'Native / Fluent',
      percentage: 100,
      description: 'Primary native language. Exceptional verbal fluency, written composition, and nuanced cultural communication.',
      color: '#FF1744',
      badge: 'NATIVE FLUENCY',
      script: 'தமிழ்',
      dashoffset: 0 // 100% full
    },
    {
      name: 'ENGLISH',
      level: 'Professional Working Proficiency',
      percentage: 75,
      description: 'Full professional working proficiency. Technical documentation, cross-functional collaboration, and software presentation.',
      color: '#D4AF37',
      badge: 'PROFESSIONAL WORKING',
      script: 'English',
      dashoffset: 62.8 // (1 - 0.75) * 2 * PI * 40 = 0.25 * 251.3 = 62.8
    }
  ];

  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/10 border border-[#FF1744]/30 text-[#FF1744] text-xs font-mono tracking-widest uppercase mb-4"
        >
          <LanguagesIcon className="w-4 h-4" />
          <span>LINGUISTIC CAPABILITIES // COMMUNICATION</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight"
        >
          LANGUAGE <span className="text-gradient-cinematic">PROFICIENCY.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-muted-grey text-base sm:text-lg max-w-2xl mx-auto"
        >
          Effective bilateral communication empowering global software collaboration and technical synergy.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {languageList.map((lang, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.15 }}
            className="relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#181112]/95 via-[#111111]/90 to-[#0A0A0A]/95 border border-white/10 hover:border-[#FF1744]/40 backdrop-blur-xl shadow-glass-card transition-all duration-300 group flex flex-col justify-between"
          >
            <div>
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-black/60 border border-white/10 flex items-center justify-center text-[#FF1744]">
                    <Globe2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl sm:text-2xl font-black font-heading text-white group-hover:text-[#F5D77B] transition-colors">
                      {lang.name}
                    </h3>
                    <span className="text-xs font-mono text-muted-grey">{lang.script}</span>
                  </div>
                </div>

                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-white/5 border border-white/10 text-[#D4AF37]">
                  {lang.badge}
                </span>
              </div>

              {/* Circular Gauge and Text */}
              <div className="flex items-center gap-6 mb-6 p-4 rounded-xl bg-black/50 border border-white/5">
                {/* Circular Indicator */}
                <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="rgba(255, 255, 255, 0.08)"
                      strokeWidth="6"
                      fill="none"
                    />
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke={lang.color}
                      strokeWidth="6"
                      fill="none"
                      strokeDasharray={251.3}
                      initial={{ strokeDashoffset: 251.3 }}
                      whileInView={{ strokeDashoffset: lang.dashoffset }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.5, ease: 'easeOut' }}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center font-mono font-bold text-lg text-white">
                    <span>{lang.percentage}%</span>
                  </div>
                </div>

                {/* Level Description */}
                <div>
                  <div className="text-xs font-mono text-muted-grey uppercase tracking-wider mb-1">
                    PROFICIENCY METRIC
                  </div>
                  <div className="text-sm font-bold font-heading text-white mb-1">
                    {lang.level}
                  </div>
                  <p className="text-xs text-muted-grey leading-relaxed">
                    {lang.description}
                  </p>
                </div>
              </div>

              {/* Animated Audio Wave Simulation */}
              <div className="flex items-center gap-1.5 h-8 mb-4 px-3 py-1.5 rounded-lg bg-black/40 border border-white/5">
                <Volume2 className="w-4 h-4 text-[#FF1744] mr-2 shrink-0" />
                {[35, 65, 95, 45, 80, 55, 90, 70, 40, 85, 65, 50, 75, 90, 60, 40, 80].map((h, bIdx) => (
                  <motion.div
                    key={bIdx}
                    className="w-1 bg-gradient-to-t from-[#FF1744] to-[#D4AF37] rounded-full"
                    animate={{
                      height: [`${h * 0.3}%`, `${h}%`, `${h * 0.4}%`],
                    }}
                    transition={{
                      duration: 1.2 + (bIdx % 5) * 0.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs font-mono pt-3 border-t border-white/10">
              <span className="text-muted-grey">ACCURACY & COMPREHENSION:</span>
              <span className="font-bold text-[#D4AF37]">{lang.percentage}% VERIFIED</span>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

