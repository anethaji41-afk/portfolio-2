import React from 'react';
import { motion } from 'framer-motion';
import Hero3DPortrait from '../canvas/Hero3DPortrait';
import { ChevronRight, Download, Terminal, MapPin } from 'lucide-react';
import { playSound } from '../../utils/audio';

interface HeroProps {
  onOpenResume: () => void;
}

export default function Hero({ onOpenResume }: HeroProps) {
  const scrollTo = (id: string) => {
    playSound('click');
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10">
      <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        
        {/* Left Column: Headlines & Call to Actions */}
        <div className="lg:col-span-7 flex flex-col justify-center text-left">
          
          {/* Top Availability & Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-wrap items-center gap-3 mb-5"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF1744]/15 border border-[#FF1744]/40 text-[#FF1744] text-xs font-mono tracking-wider backdrop-blur-md shadow-neon-red">
              <span className="w-2 h-2 rounded-full bg-[#FF1744] animate-ping" />
              <span>PORTFOLIO / 2026</span>
            </div>

            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-muted-grey text-xs font-mono">
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Tamil Nadu, India</span>
            </div>
          </motion.div>

          {/* Subheading: Name & Professional Title */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="flex items-center gap-3 mb-2 text-sm sm:text-base font-mono tracking-widest text-[#D4AF37] font-semibold uppercase"
          >
            <Terminal className="w-4 h-4 text-[#FF1744]" />
            <span>SOFTWARE DEVELOPER</span>
          </motion.div>

          {/* Main Cinematic Name Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="text-5xl sm:text-7xl md:text-8xl font-black font-heading tracking-tight leading-[1] mb-6 uppercase"
          >
            A. <span className="text-gradient-cinematic">NETHAJI</span>
          </motion.h1>

          {/* Required Slogan Quote */}
          <motion.blockquote
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.3 }}
            className="text-lg sm:text-2xl text-white font-medium italic border-l-2 border-[#FF1744] pl-4 mb-6 leading-relaxed"
          >
            "Building Digital Experiences Through Code, Creativity and Innovation."
          </motion.blockquote>

          {/* Supporting Bio Text */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="text-sm sm:text-base text-muted-grey max-w-xl font-normal leading-relaxed mb-8"
          >
            Motivated BCA student at Kalasalingam Academy and Full Stack Developer Intern at Arumexa Technology, transforming ideas into interactive, high-performance web platforms.
          </motion.p>

          {/* Two Master Functional Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="flex flex-wrap items-center gap-4 mb-10"
          >
            {/* Button 1: EXPLORE MY WORK */}
            <button
              onClick={() => scrollTo('projects')}
              className="relative group px-7 py-3.5 rounded-xl font-mono text-sm tracking-wider font-bold text-white bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] shadow-neon-red transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2 overflow-hidden"
            >
              <span className="relative z-10">[ EXPLORE MY WORK ]</span>
              <ChevronRight className="w-4 h-4 relative z-10 transition-transform duration-300 group-hover:translate-x-1" />
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </button>

            {/* Button 2: DOWNLOAD RESUME */}
            <button
              onClick={() => {
                playSound('click');
                onOpenResume();
              }}
              className="px-7 py-3.5 rounded-xl font-mono text-sm tracking-wider font-semibold text-soft-white bg-[#111111]/85 hover:bg-[#1A1A1A] border border-[#FF1744]/40 hover:border-[#FF1744] shadow-sm hover:shadow-neon-red transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2 backdrop-blur-md"
            >
              <Download className="w-4 h-4 text-[#FF1744]" />
              <span>[ DOWNLOAD RESUME ]</span>
            </button>
          </motion.div>

          {/* Quick Metrics Bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="grid grid-cols-3 gap-3 sm:gap-4 max-w-lg pt-6 border-t border-white/10"
          >
            <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5">
              <div className="text-xl sm:text-2xl font-black font-heading text-[#FF1744]">BCA</div>
              <div className="text-[11px] font-mono text-muted-grey mt-0.5">2024–2027 Student</div>
            </div>
            <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5">
              <div className="text-xl sm:text-2xl font-black font-heading text-[#D4AF37]">ARUMEXA</div>
              <div className="text-[11px] font-mono text-muted-grey mt-0.5">Full Stack Intern</div>
            </div>
            <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5">
              <div className="text-xl sm:text-2xl font-black font-heading text-[#FF6A00]">VIBE CODING</div>
              <div className="text-[11px] font-mono text-muted-grey mt-0.5">AI-Assisted Dev</div>
            </div>
          </motion.div>

        </div>

        {/* Right Column: Interactive 3D Hero Portrait */}
        <div className="lg:col-span-5 flex justify-center items-center">
          <Hero3DPortrait />
        </div>

      </div>

      {/* Bottom Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer z-20 group"
        onClick={() => scrollTo('about')}
      >
        <span className="text-[10px] font-mono tracking-widest text-muted-grey group-hover:text-[#FF1744] transition-colors uppercase">
          SCROLL TO EXPLORE
        </span>
        <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center p-1 group-hover:border-[#FF1744] transition-colors">
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
            className="w-1.5 h-1.5 rounded-full bg-[#FF1744]"
          />
        </div>
      </motion.div>
    </section>
  );
}

