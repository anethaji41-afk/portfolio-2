import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';

export interface MilestoneData {
  id: number;
  stage: string;
  year: string;
  title: string;
  institution: string;
  status: 'completed' | 'in-progress' | 'future';
  statusLabel: string;
  description: string;
  details: string;
  skills: string[];
  color: string;
  position: [number, number, number];
  size: number;
}

export const MILESTONES: MilestoneData[] = [
  {
    id: 1,
    stage: 'STAGE 01',
    year: '2022–2024',
    title: 'Higher Secondary Education',
    institution: 'TNPM Marimuthu Nadar Higher Secondary School',
    status: 'completed',
    statusLabel: 'ACADEMIC FOUNDATION',
    description: 'Developed disciplined analytical logic, physics principles, and foundational mathematical problem solving in Thalaivapuram, Tamil Nadu.',
    details: 'Completed Class XII curriculum with distinction, building a strong platform for computational and algorithmic computer science studies.',
    skills: ['Analytical Mathematics', 'Physics & Logic', 'Academic Excellence', 'Algorithmic Thinking'],
    color: '#D4AF37',
    position: [-4.2, 0, 0],
    size: 0.75,
  },
  {
    id: 2,
    stage: 'STAGE 02',
    year: '2024–2027',
    title: 'Bachelor of Computer Applications (BCA)',
    institution: 'Kalasalingam Academy of Research and Education',
    status: 'in-progress',
    statusLabel: 'UNDERGRADUATE STUDIES (PURSUING)',
    description: 'Pursuing comprehensive computer application studies, computer science principles, web architecture, and full-stack software development.',
    details: 'Focusing on modern JavaScript ecosystems, responsive UI engineering, data structures, and AI-assisted software workflows.',
    skills: ['Computer Applications', 'Web Engineering', 'Data Structures', 'Database Systems', 'React & TypeScript'],
    color: '#FF6A00',
    position: [-1.4, 1.2, 0],
    size: 0.95,
  },
  {
    id: 3,
    stage: 'STAGE 03',
    year: '2025–2026',
    title: 'Full Stack Developer Intern',
    institution: 'Arumexa Technology Private Limited',
    status: 'in-progress',
    statusLabel: 'INDUSTRY INTERNSHIP',
    description: 'Hands-on full-stack development, software-related tasks, AI-assisted development (Vibe Coding), and collaborative project implementation.',
    details: 'Leveraging modern AI tooling including Lovable and Antigravity to build scalable, resilient web platforms and streamline development velocity.',
    skills: ['Full Stack Development', 'Vibe Coding', 'AI-Assisted Tools', 'Agile Teamwork', 'Production Delivery'],
    color: '#FF1744',
    position: [1.8, -0.9, 0],
    size: 1.15,
  },
  {
    id: 4,
    stage: 'STAGE 04',
    year: '2026+',
    title: 'Future Tech Vision & Software Engineering',
    institution: 'Global Tech Innovation',
    status: 'future',
    statusLabel: 'CAREER ROADMAP',
    description: 'Engineering cutting-edge digital experiences, 3D WebGL interfaces, intelligent AI companions, and high-impact software systems.',
    details: 'Targeting deep engineering roles, cloud systems, and building innovative digital solutions that solve real-world problems.',
    skills: ['System Architecture', '3D Web Experiences', 'AI Engineering', 'Full Stack Leadership'],
    color: '#F5D77B',
    position: [4.4, 0.6, 0],
    size: 0.85,
  },
];

function OrbitPath({ radius }: { radius: number }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[radius - 0.02, radius + 0.02, 64]} />
      <meshBasicMaterial color="#FF1744" opacity={0.18} transparent side={THREE.DoubleSide} />
    </mesh>
  );
}

function PlanetNode({
  milestone,
  isSelected,
  onSelect,
}: {
  milestone: MilestoneData;
  isSelected: boolean;
  onSelect: (m: MilestoneData) => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  return (
    <group position={milestone.position}>
      <mesh
        ref={meshRef}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(milestone);
        }}
        scale={isSelected ? 1.3 : 1}
      >
        <sphereGeometry args={[milestone.size, 32, 32]} />
        <meshStandardMaterial
          color={milestone.color}
          emissive={milestone.color}
          emissiveIntensity={isSelected ? 0.9 : 0.35}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Orbit halo ring when selected */}
      {isSelected && (
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[milestone.size + 0.25, milestone.size + 0.35, 32]} />
          <meshBasicMaterial color={milestone.color} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* Label Badge */}
      <Html position={[0, milestone.size + 0.6, 0]} center distanceFactor={12}>
        <div
          onClick={() => onSelect(milestone)}
          className={`px-2.5 py-1 rounded-md text-[10px] font-mono whitespace-nowrap cursor-pointer transition-all ${
            isSelected
              ? 'bg-[#FF1744] text-white font-bold shadow-neon-red scale-110'
              : 'bg-black/80 text-muted-grey border border-white/10 hover:text-white'
          }`}
        >
          {milestone.stage} // {milestone.year}
        </div>
      </Html>
    </group>
  );
}

function Scene({
  activeMilestone,
  onSelectMilestone,
}: {
  activeMilestone: MilestoneData;
  onSelectMilestone: (m: MilestoneData) => void;
}) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Central Star Core */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial color="#FF1744" emissive="#FF1744" emissiveIntensity={1.2} />
      </mesh>

      <OrbitPath radius={2.2} />
      <OrbitPath radius={3.8} />
      <OrbitPath radius={5.2} />

      {MILESTONES.map((m) => (
        <PlanetNode
          key={m.id}
          milestone={m}
          isSelected={activeMilestone.id === m.id}
          onSelect={onSelectMilestone}
        />
      ))}
    </group>
  );
}

export default function CareerJourneyMap({
  activeMilestone,
  onSelectMilestone,
}: {
  activeMilestone: MilestoneData;
  onSelectMilestone: (m: MilestoneData) => void;
}) {
  return (
    <div className="relative w-full h-[420px] sm:h-[480px] rounded-3xl bg-black/60 border border-white/10 overflow-hidden scanline">
      <div className="absolute top-3 left-4 z-10 text-xs font-mono text-muted-grey pointer-events-none">
        <span className="text-[#FF1744] font-bold">3D ORBITAL NAVIGATOR</span> // DRAG TO ROTATE & PAN
      </div>

      <Canvas camera={{ position: [0, 4, 9], fov: 50 }}>
        <ambientLight intensity={0.6} />
        <pointLight position={[10, 10, 10]} color="#FF1744" intensity={2} />
        <pointLight position={[-10, -10, -5]} color="#D4AF37" intensity={1.5} />
        <Scene activeMilestone={activeMilestone} onSelectMilestone={onSelectMilestone} />
        <OrbitControls enableZoom={false} maxPolarAngle={Math.PI / 1.8} minPolarAngle={Math.PI / 3} />
      </Canvas>
    </div>
  );
}

