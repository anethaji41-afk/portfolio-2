import React, { useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// 1. Particle Cloud Engine (Neon Red, Electric Orange & Golden Dust)
function ParticleField({
  count = 450,
  color = '#FF1744',
  size = 0.06,
  speed = 0.25,
  spread = 35,
}: {
  count?: number;
  color?: string;
  size?: number;
  speed?: number;
  spread?: number;
}) {
  const pointsRef = useRef<THREE.Points>(null);

  const [positions, scales] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const scl = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * spread;
      pos[i * 3 + 1] = (Math.random() - 0.5) * (spread + 10);
      pos[i * 3 + 2] = (Math.random() - 0.5) * (spread - 5) - 5;
      scl[i] = Math.random() * 0.8 + 0.2;
    }
    return [pos, scl];
  }, [count, spread]);

  useFrame((state, delta) => {
    if (!pointsRef.current) return;
    pointsRef.current.rotation.y += delta * 0.02 * speed;
    pointsRef.current.rotation.x += delta * 0.01 * speed;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-scale" args={[scales, 1]} />
      </bufferGeometry>
      <pointsMaterial
        size={size}
        color={color}
        transparent
        opacity={0.7}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

// 2. Floating Metallic Spheres & Geometric Objects
function FloatingObjects({
  mouse,
  scrollY,
}: {
  mouse: React.MutableRefObject<{ x: number; y: number }>;
  scrollY: React.MutableRefObject<number>;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const sphere1 = useRef<THREE.Mesh>(null);
  const sphere2 = useRef<THREE.Mesh>(null);
  const icosahedron = useRef<THREE.Mesh>(null);
  const torusRing = useRef<THREE.Mesh>(null);
  const outerRing = useRef<THREE.Mesh>(null);
  const octahedron = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // Smooth mouse parallax
    groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, mouse.current.y * 0.15, 0.05);
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, mouse.current.x * 0.15, 0.05);

    // Scroll impact
    const scrollFactor = scrollY.current * 0.001;
    groupRef.current.position.y = THREE.MathUtils.lerp(groupRef.current.position.y, scrollFactor * 2.2, 0.05);

    const time = state.clock.getElapsedTime();

    if (sphere1.current) {
      sphere1.current.position.y = Math.sin(time * 0.8) * 0.5 + 2;
      sphere1.current.rotation.y += delta * 0.3;
    }
    if (sphere2.current) {
      sphere2.current.position.y = Math.cos(time * 0.7) * 0.6 - 3;
      sphere2.current.rotation.x += delta * 0.25;
    }
    if (icosahedron.current) {
      icosahedron.current.rotation.x += delta * 0.4;
      icosahedron.current.rotation.y += delta * 0.5;
      icosahedron.current.position.y = Math.sin(time * 0.6) * 0.4 - 1;
    }
    if (octahedron.current) {
      octahedron.current.rotation.y += delta * 0.35;
      octahedron.current.rotation.z += delta * 0.2;
      octahedron.current.position.y = Math.cos(time * 0.5) * 0.5 + 4;
    }
    if (torusRing.current) {
      torusRing.current.rotation.x += delta * 0.25;
      torusRing.current.rotation.y += delta * 0.35;
    }
    if (outerRing.current) {
      outerRing.current.rotation.x -= delta * 0.15;
      outerRing.current.rotation.z += delta * 0.25;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Metallic Gold Sphere */}
      <mesh ref={sphere1} position={[-8, 2, -6]}>
        <sphereGeometry args={[1.4, 32, 32]} />
        <meshStandardMaterial
          color="#D4AF37"
          metalness={0.9}
          roughness={0.15}
          emissive="#8B0000"
          emissiveIntensity={0.25}
        />
      </mesh>

      {/* Neon Red Chrome Sphere */}
      <mesh ref={sphere2} position={[9, -3, -8]}>
        <sphereGeometry args={[1.7, 32, 32]} />
        <meshStandardMaterial
          color="#FF1744"
          metalness={0.88}
          roughness={0.18}
          emissive="#FF1744"
          emissiveIntensity={0.35}
        />
      </mesh>

      {/* Geometric Wireframe Icosahedron */}
      <mesh ref={icosahedron} position={[7, 4, -5]}>
        <icosahedronGeometry args={[1.5, 0]} />
        <meshStandardMaterial
          color="#FF6A00"
          wireframe
          emissive="#FF1744"
          emissiveIntensity={0.7}
        />
      </mesh>

      {/* Rotating Metallic Octahedron */}
      <mesh ref={octahedron} position={[-7, -4, -4]}>
        <octahedronGeometry args={[1.3, 0]} />
        <meshStandardMaterial
          color="#F5D77B"
          metalness={0.9}
          roughness={0.1}
          wireframe
        />
      </mesh>

      {/* Interactive 3D Metallic Energy Ring */}
      <mesh ref={torusRing} position={[0, -1, -7]}>
        <torusGeometry args={[3.2, 0.06, 16, 100]} />
        <meshStandardMaterial
          color="#FF1744"
          emissive="#FF1744"
          emissiveIntensity={0.9}
        />
      </mesh>

      {/* Outer Metallic Gold Orbit Ring */}
      <mesh ref={outerRing} position={[0, -1, -7]}>
        <torusGeometry args={[4.6, 0.04, 16, 100]} />
        <meshStandardMaterial
          color="#D4AF37"
          metalness={0.9}
          roughness={0.2}
          emissive="#D4AF37"
          emissiveIntensity={0.4}
        />
      </mesh>
    </group>
  );
}

// 3. Cybernetic Ground Grid & Energy Lines
function CyberGridPlane() {
  const gridRef = useRef<THREE.GridHelper>(null);

  useFrame((state) => {
    if (!gridRef.current) return;
    gridRef.current.position.z = (state.clock.getElapsedTime() * 0.9) % 2 - 10;
  });

  return (
    <group position={[0, -7.5, 0]} rotation={[-Math.PI / 2.3, 0, 0]}>
      <gridHelper
        ref={gridRef}
        args={[80, 40, '#FF1744', '#151515']}
      />
    </group>
  );
}

// Main 3D Canvas
export default function BackgroundCanvas() {
  const mouse = useRef({ x: 0, y: 0 });
  const scrollY = useRef(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const handleScroll = () => {
      scrollY.current = window.scrollY;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#050505]">
      {/* Cinematic ambient gradient spotlights */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#FF1744]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[600px] h-[600px] bg-[#D4AF37]/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute top-2/3 left-1/3 w-[450px] h-[450px] bg-[#FF6A00]/10 rounded-full blur-[130px] pointer-events-none" />

      <Canvas
        camera={{ position: [0, 0, 10], fov: 60 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      >
        <ambientLight intensity={0.5} />
        {/* Dynamic neon red & gold cinematic lights */}
        <pointLight position={[10, 10, 10]} color="#FF1744" intensity={2.2} distance={50} />
        <pointLight position={[-10, -10, -10]} color="#D4AF37" intensity={1.5} distance={50} />
        <directionalLight position={[0, 10, 5]} color="#FF6A00" intensity={1.2} />
        <directionalLight position={[-5, -5, 2]} color="#8B0000" intensity={0.9} />

        {/* 1. Floating 3D objects */}
        <FloatingObjects mouse={mouse} scrollY={scrollY} />

        {/* 2. Glowing Neon Red Particles */}
        <ParticleField count={450} color="#FF1744" size={0.07} speed={0.25} />

        {/* 3. Electric Orange Particles */}
        <ParticleField count={300} color="#FF6A00" size={0.05} speed={0.35} />

        {/* 4. Golden Dust Particles */}
        <ParticleField count={250} color="#F5D77B" size={0.04} speed={0.4} />

        {/* 5. Deep Red Atmospheric Particles */}
        <ParticleField count={180} color="#8B0000" size={0.05} speed={0.15} />

        {/* 6. Cybernetic Ground Grid */}
        <CyberGridPlane />
      </Canvas>
    </div>
  );
}

