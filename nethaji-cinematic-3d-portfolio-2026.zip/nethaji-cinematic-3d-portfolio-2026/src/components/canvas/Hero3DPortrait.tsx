import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ShieldCheck, Sparkles } from 'lucide-react';

// 3D Gyro Ring system
function GyroRings() {
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);
  const ring3 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (ring1.current) {
      ring1.current.rotation.x += delta * 0.45;
      ring1.current.rotation.y += delta * 0.35;
    }
    if (ring2.current) {
      ring2.current.rotation.y -= delta * 0.38;
      ring2.current.rotation.z += delta * 0.28;
    }
    if (ring3.current) {
      ring3.current.rotation.x += delta * 0.22;
      ring3.current.rotation.z -= delta * 0.42;
    }
  });

  return (
    <group position={[0, 0, 0]}>
      {/* Neon Red Energy Ring */}
      <mesh ref={ring1}>
        <torusGeometry args={[3.2, 0.035, 16, 100]} />
        <meshStandardMaterial color="#FF1744" emissive="#FF1744" emissiveIntensity={0.9} />
      </mesh>
      {/* Metallic Gold Orbit Ring */}
      <mesh ref={ring2}>
        <torusGeometry args={[3.7, 0.025, 16, 100]} />
        <meshStandardMaterial color="#D4AF37" metalness={0.9} roughness={0.15} emissive="#D4AF37" emissiveIntensity={0.5} />
      </mesh>
      {/* Electric Orange Kinetic Ring */}
      <mesh ref={ring3}>
        <torusGeometry args={[4.2, 0.02, 16, 100]} />
        <meshStandardMaterial color="#FF6A00" emissive="#FF6A00" emissiveIntensity={0.7} />
      </mesh>
    </group>
  );
}

export default function Hero3DPortrait() {
  const cardRef = useRef<HTMLDivElement>(null);

  // Mouse tilt physics with springs
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x, { stiffness: 150, damping: 15 });
  const mouseYSpring = useSpring(y, { stiffness: 150, damping: 15 });

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ['14deg', '-14deg']);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ['-14deg', '14deg']);
  const glareX = useTransform(mouseXSpring, [-0.5, 0.5], ['0%', '100%']);
  const glareY = useTransform(mouseYSpring, [-0.5, 0.5], ['0%', '100%']);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = (e.clientX - rect.left) / width - 0.5;
    const mouseY = (e.clientY - rect.top) / height - 0.5;
    x.set(mouseX);
    y.set(mouseY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div className="relative w-full max-w-[480px] lg:max-w-[540px] aspect-[4/5] mx-auto flex items-center justify-center">
      {/* 3D WebGL Background Gyro Rings */}
      <div className="absolute inset-0 pointer-events-none scale-125 z-0">
        <Canvas camera={{ position: [0, 0, 8], fov: 50 }} gl={{ alpha: true }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[5, 5, 5]} color="#FF1744" intensity={2} />
          <pointLight position={[-5, -5, -2]} color="#D4AF37" intensity={1.5} />
          <GyroRings />
        </Canvas>
      </div>

      {/* Outer Pulse Glow */}
      <div className="absolute -inset-4 bg-gradient-to-r from-[#FF1744]/25 via-[#FF6A00]/20 to-[#D4AF37]/20 rounded-3xl blur-2xl -z-10 animate-pulse-slow pointer-events-none" />

      {/* Interactive 3D Holographic Card */}
      <motion.div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
        }}
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full h-full rounded-2xl p-2.5 sm:p-3.5 bg-gradient-to-b from-[#1C1214]/90 via-[#111111]/90 to-[#0A0A0A]/95 backdrop-blur-xl border border-[#FF1744]/40 shadow-neon-red group cursor-pointer transition-shadow duration-500 hover:border-[#FF1744] hover:shadow-[0_0_35px_rgba(255,23,68,0.6)]"
      >
        {/* Holographic Glare Overlay */}
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none opacity-0 group-hover:opacity-40 transition-opacity duration-300 z-30"
          style={{
            background: `radial-gradient(circle at ${glareX} ${glareY}, rgba(255, 23, 68, 0.45), transparent 60%)`,
          }}
        />

        {/* Cyber HUD Corner Brackets */}
        <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#FF1744] z-20 pointer-events-none" />
        <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#D4AF37] z-20 pointer-events-none" />
        <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#D4AF37] z-20 pointer-events-none" />
        <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#FF1744] z-20 pointer-events-none" />

        {/* Image Container with Scanning Line */}
        <div className="relative w-full h-full rounded-xl overflow-hidden bg-black scanline">
          {/* Authentic portrait of A. Nethaji */}
          <img
            src="/profile.jpg"
            alt="A. Nethaji - Software Developer"
            className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
            loading="eager"
          />

          {/* Vignette Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-black/35 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/40 pointer-events-none" />

          {/* Top HUD Status */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-none text-xs font-mono">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 border border-[#FF1744]/50 text-[#FF1744] backdrop-blur-md shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#FF1744] animate-ping" />
              SYSTEM ACTIVE // 60 FPS
            </span>
            <span className="px-2.5 py-1 rounded-full bg-black/75 border border-[#D4AF37]/50 text-[#F5D77B] backdrop-blur-md">
              PORTFOLIO / 2026
            </span>
          </div>

          {/* Bottom Holographic HUD Bar */}
          <div className="absolute bottom-3 left-3 right-3 p-3 rounded-xl bg-black/85 backdrop-blur-md border border-white/10 z-20 pointer-events-none flex items-center justify-between">
            <div>
              <div className="text-[10px] tracking-widest text-muted-grey font-mono uppercase">VERIFIED IDENTITY</div>
              <div className="text-sm font-bold text-soft-white flex items-center gap-1.5 font-heading">
                A. NETHAJI
                <ShieldCheck className="w-4 h-4 text-[#FF1744]" />
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] tracking-widest text-[#FF1744] font-mono uppercase">ROLE</div>
              <div className="text-xs font-semibold text-[#F5D77B] font-mono">SOFTWARE DEVELOPER</div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

