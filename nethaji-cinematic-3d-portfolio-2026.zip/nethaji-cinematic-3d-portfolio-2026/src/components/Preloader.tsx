import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal } from 'lucide-react';

export default function Preloader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('INITIALIZING NEURAL 3D INTERFACE...');

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }

        const next = prev + Math.floor(Math.random() * 8) + 4;
        if (next > 25 && next < 55) {
          setStatusText('SYNCHRONIZING CINEMATIC 3D ENGINE...');
        } else if (next >= 55 && next < 85) {
          setStatusText('LOADING VERIFIED DOSSIER & PROJECTS...');
        } else if (next >= 85) {
          setStatusText('SYSTEM ONLINE // READY TO ENGAGE.');
        }

        return next > 100 ? 100 : next;
      });
    }, 40);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: 'easeInOut' }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050505] p-6 text-center select-none"
    >
      <div className="w-full max-w-md space-y-6">
        
        {/* Animated Cyber Monogram */}
        <div className="relative mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#FF1744] via-[#FF6A00] to-[#D4AF37] p-[2px] shadow-neon-red">
          <div className="w-full h-full bg-black rounded-[14px] flex items-center justify-center">
            <span className="font-heading font-black text-2xl text-[#FF1744] animate-pulse">N</span>
          </div>
        </div>

        {/* Title */}
        <div>
          <h2 className="text-xl sm:text-2xl font-black font-heading text-white tracking-widest uppercase">
            A. NETHAJI
          </h2>
          <div className="text-xs font-mono text-[#D4AF37] tracking-widest mt-1">
            IMMERSIVE 3D CINEMATIC PORTFOLIO / 2026
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden relative">
          <motion.div
            className="h-full bg-gradient-to-r from-[#FF1744] via-[#FF6A00] to-[#D4AF37] shadow-neon-red"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Status Line */}
        <div className="flex items-center justify-between text-xs font-mono text-muted-grey">
          <span className="flex items-center gap-1.5 text-[#FF1744]">
            <Terminal className="w-3.5 h-3.5 animate-spin-slow" />
            {statusText}
          </span>
          <span className="font-bold text-white">{progress}%</span>
        </div>

      </div>
    </motion.div>
  );
}

