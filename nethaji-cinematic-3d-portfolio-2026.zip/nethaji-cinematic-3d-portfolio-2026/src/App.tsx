import React, { useState } from 'react';
import BackgroundCanvas from './components/canvas/BackgroundCanvas';
import Navbar from './components/Navbar';
import Hero from './components/sections/Hero';
import About from './components/sections/About';
import Experience from './components/sections/Experience';
import Skills from './components/sections/Skills';
import Projects from './components/sections/Projects';
import CareerJourney from './components/sections/CareerJourney';
import Education from './components/sections/Education';
import Languages from './components/sections/Languages';
import Contact from './components/sections/Contact';
import Footer from './components/Footer';
import CustomCursor from './components/CustomCursor';
import Preloader from './components/Preloader';
import ResumeModal from './components/ResumeModal';
import ScrollToTop from './components/ScrollToTop';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [resumeOpen, setResumeOpen] = useState(false);

  return (
    <div className="relative min-h-screen bg-[#050505] text-[#F8F8F8] selection:bg-[#FF1744] selection:text-white overflow-x-hidden font-display">
      {/* 1. Cinematic Preloader */}
      {loading && <Preloader onComplete={() => setLoading(false)} />}

      {/* 2. Custom Interactive Magnetic Cursor */}
      <CustomCursor />

      {/* 3. Real-time 3D WebGL Background Canvas */}
      <BackgroundCanvas />

      {/* 4. Floating Glass Navbar */}
      <Navbar onOpenResume={() => setResumeOpen(true)} />

      {/* 5. Main Content Sections */}
      <main className="relative z-10">
        <Hero onOpenResume={() => setResumeOpen(true)} />
        <About />
        <Experience />
        <Skills />
        <Projects />
        <CareerJourney />
        <Education />
        <Languages />
        <Contact />
      </main>

      {/* 6. Footer */}
      <Footer />

      {/* 7. Scroll-To-Top Circular Button */}
      <ScrollToTop />

      {/* 8. Official Resume Viewer & Downloader Modal */}
      <ResumeModal
        isOpen={resumeOpen}
        onClose={() => setResumeOpen(false)}
      />
    </div>
  );
}

