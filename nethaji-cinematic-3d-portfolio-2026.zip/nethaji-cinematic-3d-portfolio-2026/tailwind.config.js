/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'deep-black': '#050505',
        'dark-bg': '#0A0A0A',
        'charcoal': '#151515',
        'card-bg': '#111111',
        'neon-red': '#FF1744',
        'dark-red': '#8B0000',
        'crimson-red': '#B91C1C',
        'electric-orange': '#FF6A00',
        'neon-orange': '#FF8C00',
        'metallic-gold': '#D4AF37',
        'light-gold': '#F5D77B',
        'muted-grey': '#A8A8A8',
        'soft-white': '#F8F8F8',
      },
      fontFamily: {
        heading: ['"Space Grotesk"', 'sans-serif'],
        display: ['"Outfit"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        'radial-glow': 'radial-gradient(circle at center, rgba(255, 23, 68, 0.15) 0%, transparent 70%)',
        'orange-glow': 'radial-gradient(circle at center, rgba(255, 106, 0, 0.15) 0%, transparent 70%)',
        'gold-glow': 'radial-gradient(circle at center, rgba(212, 175, 55, 0.15) 0%, transparent 70%)',
        'red-orange-gold': 'linear-gradient(135deg, #FF1744 0%, #FF6A00 50%, #D4AF37 100%)',
        'card-gradient': 'linear-gradient(180deg, rgba(21, 21, 21, 0.85) 0%, rgba(10, 10, 10, 0.95) 100%)',
      },
      boxShadow: {
        'neon-red': '0 0 25px -5px rgba(255, 23, 68, 0.6), 0 0 10px -5px rgba(255, 23, 68, 0.4)',
        'neon-orange': '0 0 25px -5px rgba(255, 106, 0, 0.6), 0 0 10px -5px rgba(255, 140, 0, 0.4)',
        'neon-gold': '0 0 25px -5px rgba(212, 175, 55, 0.5), 0 0 10px -5px rgba(245, 215, 123, 0.3)',
        'glass-card': '0 8px 32px 0 rgba(0, 0, 0, 0.7), inset 0 0 0 1px rgba(255, 255, 255, 0.08)',
        'cyber-border': '0 0 0 1px rgba(255, 23, 68, 0.3), 0 4px 20px rgba(0, 0, 0, 0.8)',
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'spin-slow': 'spin 20s linear infinite',
        'float': 'float 6s ease-in-out infinite',
        'scan': 'scan 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        scan: {
          '0%': { top: '0%' },
          '100%': { top: '100%' },
        }
      }
    },
  },
  plugins: [],
}

