# A. NETHAJI — Immersive 3D Cinematic Developer Portfolio 2026

A futuristic, highly interactive 3D developer portfolio website for **A. Nethaji**, Software Developer & BCA Scholar.

Built with **React 18**, **TypeScript**, **Three.js**, **React Three Fiber (R3F)**, **Drei**, **Framer Motion**, **Tailwind CSS**, and **Vite**.

---

## 🌟 Key Features

1. **Cinematic Hero Section**:
   - 3D Holographic Portrait Card featuring A. Nethaji's authentic photo.
   - Interactive 3D metallic gyro rings with real-time lighting and shadows.
   - Dynamic scanning light line and cybernetic targeting reticles.
   - Direct call-to-actions: `[ EXPLORE MY WORK ]` and `[ DOWNLOAD RESUME ]`.

2. **Real-Time 3D WebGL Background Engine (Three.js & R3F)**:
   - 1,180+ glowing particles and golden dust effect across multiple depth layers.
   - Floating metallic meshes (metallic gold spheres, neon red chrome spheres, rotating wireframe icosahedrons, octahedrons, and energy toruses).
   - Cybernetic ground grid with cursor parallax and scroll speed scaling.
   - Dynamic point lights (Neon Red `#FF1744`, Metallic Gold `#D4AF37`, Electric Orange `#FF6A00`).

3. **3D Planetary Career Mapping System**:
   - Interactive 3D orbital map with 4 celestial planets representing career milestones:
     - **Stage 01 (2022–2024)**: Higher Secondary Education (TNPM Marimuthu Nadar School).
     - **Stage 02 (2024–2027)**: Bachelor of Computer Applications (Kalasalingam Academy).
     - **Stage 03 (2025–2026)**: Full Stack Developer Intern (Arumexa Technology).
     - **Stage 04 (2026+)**: Future Tech Vision & Architectural Leadership.
   - Dynamic holographic HUD data panel updating upon selecting any planetary node.
   - 3D OrbitControls (Rotate, Pan, Zoom).

4. **Digital Toolkit (Skills Matrix)**:
   - 3D hover cards with category filtering (All, Web Development, Programming, AI & Innovation, Professional).
   - Confirmed competencies in HTML, CSS, JavaScript, React, TypeScript, Python, Java, C, C++, Vibe Coding, and Agile Teamwork.

5. **Selected Works (Project Showcase)**:
   - **EDUAI Friend**: AI-Powered Daily Study Companion ([Live App](https://eduai-friend.lovable.app)).
   - **AI-Based Fake Job and Internship Detection System**: Cybersecurity Decision-Support Tool ([Live App](https://anethaji41-afk.github.io/AI-Based-Fake-Job-and-Internship-Detection-System/)).
   - **Digital Friend**: AI-Powered Voice Companion ([Live App](https://digital-friend-voice.lovable.app)).

6. **Academic Education & Languages**:
   - Timeline cards for Kalasalingam Academy of Research and Education & TNPM Marimuthu Nadar School.
   - Animated circular SVG gauges and audio wave frequency visualizers for **Tamil (100% Native)** and **English (75% Professional Working)**.

7. **Direct Contact Channels & Resume Modal**:
   - One-click copy for email (`anethaji41@gmail.com`) and phone (`+91 76038 92617`).
   - Interactive validated message transmission form.
   - Vector PDF resume viewer modal with one-click download of `NETHAJI_A.pdf` and direct open-in-tab option.

8. **Synthesized Sci-Fi Audio**:
   - Web Audio API synthesizer for futuristic interface clicks and hums (zero external audio file dependencies).

---

## 🚀 How to Run Locally

### Prerequisites
- Node.js (v18 or higher recommended)

### Quick Start
1. Unzip the project folder.
2. Open terminal inside the project directory:
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
4. Open the local URL printed in your terminal (usually `http://localhost:3000/`).

---

## 📦 How to Build for Production

To create an optimized production bundle:
```bash
npm run build
```
The output is generated inside the `dist/` directory and can be deployed directly to Vercel, Netlify, GitHub Pages, or any static hosting service.
